# Security Policy

## Reporting a Vulnerability

Please report vulnerabilities to our bug bounty program at https://bugbounty.meta.com/
