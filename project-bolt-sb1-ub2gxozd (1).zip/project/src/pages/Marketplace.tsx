import { Search, Filter, Star, X, ChevronDown, Users, ShoppingBag, Clock, DollarSign, TrendingUp } from 'lucide-react';
import { useState, useEffect } from 'react';

interface Listing {
  id: number;
  title: string;
  description: string;
  category: string;
  price: string;
  rating: number;
  image: string;
  features: string[];
  seller: {
    name: string;
    rating: number;
    totalSales: number;
  };
  activeUsers: number;
  monthlyTransactions: number;
  monthlyRevenue: number;
  growthRate: number;
}

export default function Marketplace() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [priceRange, setPriceRange] = useState<string>('');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedListing, setSelectedListing] = useState<Listing | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Simulate loading state
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  const categories = ['Marketing', 'Development', 'Content', 'Design', 'Consulting'];
  const priceRanges = [
    'Under $1,000',
    '$1,000 - $5,000',
    '$5,000 - $10,000',
    '$10,000+'
  ];

  const listings: Listing[] = [
    {
      id: 1,
      title: "Digital Marketing Agency",
      description: "Full-service digital marketing agency specializing in SEO, PPC, and social media marketing. We help businesses grow their online presence and generate leads through data-driven strategies.",
      category: "Marketing",
      price: "$1,000-5,000/month",
      rating: 4.8,
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      features: ["SEO Optimization", "Social Media Management", "PPC Campaigns", "Analytics Reporting"],
      seller: {
        name: "Digital Growth Experts",
        rating: 4.9,
        totalSales: 156
      },
      activeUsers: 2500,
      monthlyTransactions: 180,
      monthlyRevenue: 450000,
      growthRate: 15
    },
    {
      id: 2,
      title: "E-commerce Development",
      description: "Custom e-commerce solutions using modern technologies and best practices. We build scalable online stores that drive sales and provide excellent user experience.",
      category: "Development",
      price: "$5,000-15,000",
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      features: ["Custom Design", "Mobile Responsive", "Payment Integration", "Inventory Management"],
      seller: {
        name: "WebTech Solutions",
        rating: 4.8,
        totalSales: 89
      },
      activeUsers: 1800,
      monthlyTransactions: 120,
      monthlyRevenue: 720000,
      growthRate: 22
    },
    {
      id: 3,
      title: "Content Creation Service",
      description: "Professional content creation for blogs, social media, and marketing materials. Our team of expert writers delivers engaging content that resonates with your target audience.",
      category: "Content",
      price: "$500-2,000/month",
      rating: 4.7,
      image: "https://images.unsplash.com/photo-1542435503-956c469947f6?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      features: ["Blog Writing", "Social Media Content", "Email Newsletters", "Content Strategy"],
      seller: {
        name: "Content Creators Co",
        rating: 4.7,
        totalSales: 234
      },
      activeUsers: 3200,
      monthlyTransactions: 250,
      monthlyRevenue: 375000,
      growthRate: 18
    },
    {
      id: 4,
      title: "UI/UX Design Services",
      description: "Professional UI/UX design services for web and mobile applications. We create beautiful, intuitive interfaces that users love.",
      category: "Design",
      price: "$3,000-8,000",
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1561070791-2526d30994b5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      features: ["User Research", "Wireframing", "Prototyping", "Design Systems"],
      seller: {
        name: "Design Masters",
        rating: 4.9,
        totalSales: 178
      },
      activeUsers: 1500,
      monthlyTransactions: 95,
      monthlyRevenue: 475000,
      growthRate: 25
    },
    {
      id: 5,
      title: "Business Strategy Consulting",
      description: "Expert business strategy consulting to help you scale your digital business. Get actionable insights and guidance from experienced entrepreneurs.",
      category: "Consulting",
      price: "$2,000-6,000/month",
      rating: 4.8,
      image: "https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      features: ["Market Analysis", "Growth Strategy", "Competition Research", "Business Planning"],
      seller: {
        name: "Growth Advisors",
        rating: 4.8,
        totalSales: 145
      },
      activeUsers: 2100,
      monthlyTransactions: 160,
      monthlyRevenue: 640000,
      growthRate: 20
    }
  ];

  const totalActiveUsers = listings.reduce((sum, listing) => sum + listing.activeUsers, 0);
  const totalMonthlyTransactions = listings.reduce((sum, listing) => sum + listing.monthlyTransactions, 0);
  const totalMonthlyRevenue = listings.reduce((sum, listing) => sum + listing.monthlyRevenue, 0);
  const averageGrowthRate = listings.reduce((sum, listing) => sum + listing.growthRate, 0) / listings.length;

  const filteredListings = listings.filter(listing => {
    const matchesSearch = listing.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      listing.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || listing.category === selectedCategory;
    const matchesPriceRange = !priceRange || listing.price.includes(priceRange.split(' ')[0]);
    return matchesSearch && matchesCategory && matchesPriceRange;
  });

  const ListingModal = ({ listing }: { listing: Listing }) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto animate-fadeIn">
        <div className="relative">
          <button
            onClick={() => setSelectedListing(null)}
            className="absolute right-4 top-4 text-gray-500 hover:text-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
          <img
            src={listing.image}
            alt={listing.title}
            className="w-full h-64 object-cover rounded-t-lg"
          />
        </div>
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">{listing.title}</h2>
              <p className="text-gray-600">{listing.category}</p>
            </div>
            <div className="text-right">
              <p className="text-xl font-bold text-blue-600">{listing.price}</p>
              <div className="flex items-center mt-1">
                <Star className="h-5 w-5 text-yellow-400 fill-current" />
                <span className="ml-1 text-gray-600">{listing.rating}</span>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-purple-50 p-4 rounded-lg transform hover:scale-105 transition-transform">
              <div className="flex items-center text-purple-600">
                <Users className="h-5 w-5 mr-2" />
                <span className="font-semibold">{listing.activeUsers.toLocaleString()}</span>
              </div>
              <p className="text-sm text-purple-700 mt-1">Active Users</p>
            </div>
            <div className="bg-teal-50 p-4 rounded-lg transform hover:scale-105 transition-transform">
              <div className="flex items-center text-teal-600">
                <ShoppingBag className="h-5 w-5 mr-2" />
                <span className="font-semibold">{listing.monthlyTransactions.toLocaleString()}</span>
              </div>
              <p className="text-sm text-teal-700 mt-1">Monthly Transactions</p>
            </div>
            <div className="bg-blue-50 p-4 rounded-lg transform hover:scale-105 transition-transform">
              <div className="flex items-center text-blue-600">
                <DollarSign className="h-5 w-5 mr-2" />
                <span className="font-semibold">${(listing.monthlyRevenue / 1000).toFixed(1)}k</span>
              </div>
              <p className="text-sm text-blue-700 mt-1">Monthly Revenue</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg transform hover:scale-105 transition-transform">
              <div className="flex items-center text-green-600">
                <TrendingUp className="h-5 w-5 mr-2" />
                <span className="font-semibold">+{listing.growthRate}%</span>
              </div>
              <p className="text-sm text-green-700 mt-1">Growth Rate</p>
            </div>
          </div>
          
          <p className="text-gray-700 mb-6">{listing.description}</p>
          
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-2">Key Features</h3>
            <ul className="grid grid-cols-2 gap-2">
              {listing.features.map((feature, index) => (
                <li key={index} className="flex items-center text-gray-600 transform hover:translate-x-2 transition-transform">
                  <span className="w-2 h-2 bg-blue-600 rounded-full mr-2"></span>
                  {feature}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="border-t pt-6">
            <h3 className="text-lg font-semibold mb-2">About the Seller</h3>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-900">{listing.seller.name}</p>
                <div className="flex items-center mt-1">
                  <Star className="h-4 w-4 text-yellow-400 fill-current" />
                  <span className="ml-1 text-sm text-gray-600">{listing.seller.rating}</span>
                  <span className="mx-2 text-gray-300">|</span>
                  <span className="text-sm text-gray-600">{listing.seller.totalSales} sales</span>
                </div>
              </div>
              <button className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-2 rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all transform hover:scale-105">
                Contact Seller
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-6 text-white transform hover:scale-105 transition-all">
            <div className="flex items-center">
              <Users className="h-8 w-8 mr-3" />
              <div>
                <p className="text-2xl font-bold">{totalActiveUsers.toLocaleString()}</p>
                <p className="text-purple-100">Active Users</p>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-r from-teal-500 to-teal-600 rounded-lg p-6 text-white transform hover:scale-105 transition-all">
            <div className="flex items-center">
              <ShoppingBag className="h-8 w-8 mr-3" />
              <div>
                <p className="text-2xl font-bold">{totalMonthlyTransactions.toLocaleString()}</p>
                <p className="text-teal-100">Transactions</p>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 text-white transform hover:scale-105 transition-all">
            <div className="flex items-center">
              <DollarSign className="h-8 w-8 mr-3" />
              <div>
                <p className="text-2xl font-bold">${(totalMonthlyRevenue / 1000000).toFixed(1)}M</p>
                <p className="text-blue-100">Monthly Revenue</p>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white transform hover:scale-105 transition-all">
            <div className="flex items-center">
              <TrendingUp className="h-8 w-8 mr-3" />
              <div>
                <p className="text-2xl font-bold">+{averageGrowthRate.toFixed(1)}%</p>
                <p className="text-green-100">Avg Growth</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-8 animate-fadeIn">
          <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
            Digital Services Marketplace
          </h1>
          <p className="mt-2 text-gray-600">Find the perfect digital service for your business</p>
        </div>

        {/* Search and Filter Section */}
        <div className="flex flex-col md:flex-row gap-4 mb-8 animate-slideDown">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="Search services..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
          <button
            className="flex items-center px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-all transform hover:scale-105"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="h-5 w-5 mr-2" />
            Filters
            <ChevronDown className={`h-5 w-5 ml-2 transition-transform duration-300 ${showFilters ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <div className="bg-white p-4 rounded-lg shadow-sm mb-8 animate-slideDown">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                >
                  <option value="">All Categories</option>
                  {categories.map((category) => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Price Range</label>
                <select
                  value={priceRange}
                  onChange={(e) => setPriceRange(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                >
                  <option value="">All Prices</option>
                  {priceRanges.map((range) => (
                    <option key={range} value={range}>{range}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Listings Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredListings.map((listing, index) => (
            <div
              key={listing.id}
              className={`bg-white rounded-lg shadow-md overflow-hidden cursor-pointer transform hover:scale-[1.02] transition-all animate-fadeIn`}
              style={{ animationDelay: `${index * 100}ms` }}
              onClick={() => setSelectedListing(listing)}
            >
              <img
                src={listing.image}
                alt={listing.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">{listing.title}</h3>
                    <p className="text-sm text-gray-500">{listing.category}</p>
                  </div>
                  <div className="flex items-center">
                    <Star className="h-5 w-5 text-yellow-400 fill-current" />
                    <span className="ml-1 text-sm text-gray-600">{listing.rating}</span>
                  </div>
                </div>
                <p className="mt-2 text-gray-600 line-clamp-2">{listing.description}</p>
                <div className="mt-4 grid grid-cols-2 gap-2">
                  <div className="flex items-center text-purple-600 text-sm">
                    <Users className="h-4 w-4 mr-1" />
                    <span>{listing.activeUsers.toLocaleString()} users</span>
                  </div>
                  <div className="flex items-center text-green-600 text-sm">
                    <TrendingUp className="h-4 w-4 mr-1" />
                    <span>+{listing.growthRate}% growth</span>
                  </div>
                  <div className="flex items-center text-blue-600 text-sm">
                    <DollarSign className="h-4 w-4 mr-1" />
                    <span>${(listing.monthlyRevenue / 1000).toFixed(1)}k /mo</span>
                  </div>
                  <div className="flex items-center text-teal-600 text-sm">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>{listing.monthlyTransactions} /mo</span>
                  </div>
                </div>
                <div className="mt-4 flex justify-between items-center">
                  <span className="text-sm font-medium text-blue-600">{listing.price}</span>
                  <span className="text-sm text-gray-500">{listing.seller.name}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Listing Modal */}
        {selectedListing && <ListingModal listing={selectedListing} />}
      </div>
    </div>
  );
}