import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { DepartmentBudget } from '../types';

interface BudgetChartProps {
  data: DepartmentBudget[];
}

export const BudgetChart: React.FC<BudgetChartProps> = ({ data }) => {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="department" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Bar dataKey="allocated" fill="#4F46E5" name="Allocated Budget" />
        <Bar dataKey="spent" fill="#10B981" name="Spent" />
      </BarChart>
    </ResponsiveContainer>
  );
};