import { FinancialEntry, DepartmentBudget } from './types';

export const financialData: FinancialEntry[] = [
  {
    id: '1',
    date: '2024-03-01',
    category: 'Software Licenses',
    amount: 12500,
    description: 'Annual cybersecurity tool subscriptions',
    department: 'Security Operations'
  },
  {
    id: '2',
    date: '2024-03-05',
    category: 'Training',
    amount: 8000,
    description: 'Staff certification programs',
    department: 'Human Resources'
  },
  {
    id: '3',
    date: '2024-03-10',
    category: 'Hardware',
    amount: 15000,
    description: 'Security infrastructure upgrade',
    department: 'Infrastructure'
  }
];

export const departmentBudgets: DepartmentBudget[] = [
  {
    department: 'Security Operations',
    allocated: 250000,
    spent: 180000
  },
  {
    department: 'Infrastructure',
    allocated: 300000,
    spent: 220000
  },
  {
    department: 'Human Resources',
    allocated: 150000,
    spent: 95000
  }
];