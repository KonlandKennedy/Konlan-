export interface FinancialEntry {
  id: string;
  date: string;
  category: string;
  amount: number;
  description: string;
  department: string;
}

export interface DepartmentBudget {
  department: string;
  allocated: number;
  spent: number;
}